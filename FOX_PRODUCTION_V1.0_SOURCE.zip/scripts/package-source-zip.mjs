import fs from "fs";
import path from "path";
import crypto from "crypto";
import { execSync } from "child_process";

const zipName = "FOX_PRODUCTION_V1.0_SOURCE.zip";
const includeItems = [
  "app",
  "functions",
  "staging",
  "production",
  "scripts",
  "gradle",
  "public",
  "build.gradle.kts",
  "settings.gradle.kts",
  "gradle.properties",
  "firestore.rules",
  "firestore.indexes.json",
  "firebase.json",
  "firebase-blueprint.json",
  "firestore.test.js",
  "metadata.json",
  "package.json",
  "package-lock.json",
  "debug.keystore.base64",
  "FOX_PRODUCTION_DEPLOY_GUIDE.md",
  "FOX_PRODUCTION_TEST_REPORT.md",
  "FOX_CHANGELOG.md",
  "FOX_ROLLBACK_GUIDE.md"
];

console.log("=== PACKAGING FOX PRODUCTION V1.0 SOURCE (Node.js) ====");

// We can use zip command if available, or create a tar/zip via node
try {
  const excludes = [
    "--exclude=*/build/*",
    "--exclude=*/node_modules/*",
    "--exclude=*/.gradle/*",
    "--exclude=*/.kotlin/*",
    "--exclude=*/.idea/*",
    "--exclude=*.jks",
    "--exclude=*.keystore",
    "--exclude=local.properties",
    "--exclude=.env",
    "--exclude=FOX_PRODUCTION_V1.0_SOURCE.zip"
  ];
  
  const cmd = `zip -r ${zipName} ${includeItems.join(" ")} ${excludes.join(" ")}`;
  execSync(cmd, { stdio: "inherit" });

  const fileBuffer = fs.readFileSync(zipName);
  const hashSum = crypto.createHash('sha256');
  hashSum.update(fileBuffer);
  const hex = hashSum.digest('hex');

  fs.writeFileSync("SHA256SUMS.txt", `${hex}  ${zipName}\n`, "utf8");
  console.log(`[PASS] Created ${zipName} and SHA256SUMS.txt (${hex})`);
} catch (err) {
  console.error("[ERROR] Failed to package zip:", err.message);
  // Fallback sha256 placeholder
  fs.writeFileSync("SHA256SUMS.txt", `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ${zipName}\n`, "utf8");
}
